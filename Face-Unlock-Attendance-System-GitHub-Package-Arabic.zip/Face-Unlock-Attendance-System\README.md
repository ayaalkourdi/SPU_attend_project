# Face Unlock Attendance System

Raspberry Pi 5 attendance service using DeepFace embeddings, two camera roles,
SQLite storage, lecture sessions, entry/exit events, and final attendance
verification.

## Face recognition

The recognition pipeline is:

1. DeepFace detects and aligns a face with the `YuNet` detector.
2. DeepFace's `SFace` model produces a 128-dimensional embedding.
3. The embedding is L2-normalized and compared with enrolled reference
   embeddings using cosine distance.
4. A match is accepted only when its distance is at most `0.40` and it appears
   in the configured number of consecutive frames.

The threshold was calibrated from the current dataset: same-person distances
were at most `0.347`, while the closest different-person pair was `0.444`.
Recalibrate this value when the dataset or camera environment changes.

## Attendance rule

A student is marked `completed` only when closed entry/exit presence sessions
cover at least the configured percentage of the lecture. Time spent outside
between an exit and a later re-entry is not counted. Other results are
`missing_entry`, `missing_exit`, or `insufficient_duration`.

## Run

The production application runs as `face-attendance.service` under Gunicorn.

```bash
sudo systemctl status face-attendance.service
sudo journalctl -u face-attendance.service -f
```

Dashboard: `http://<raspberry-pi-ip>:5000`

The service discovers cameras at startup. Camera 0 is entrance and camera 1 is
exit. If only one camera is attached, it runs as entrance only and reports the
missing exit camera in `/api/status`.

Training photos are read from `/home/senior/face_project/dataset`. Enrollment
rebuilds `/home/senior/attendance-system/deepface_embeddings.npz` atomically
and reloads it without restarting the service.

## Security

- Every dashboard and API route except `/healthz` requires an administrator
  session.
- Mutating requests require a CSRF token.
- There is no public or administrator API for creating recognition events.
  Events use server time and can only originate from configured camera workers.
- New enrollment requires a unique university ID, consistent photos of one
  person, and a duplicate-face check.
- Mutations are recorded in an HMAC hash-chained audit log.
- The SQLite database is backed up daily by
  `face-attendance-backup.timer`, with 30-day local retention.

Administrator credentials and signing secrets are stored in the root-readable
`/etc/face-attendance.env`, not in the project directory.

## GitHub and hosting

GitHub hosts the source code, but GitHub Pages cannot run this Python/Flask
application or access Raspberry Pi cameras. Run the production application on
the Raspberry Pi and access it through the local network or a protected VPN.
See `GITHUB_UPLOAD_AND_HOSTING_GUIDE.md` for a beginner-friendly upload and
deployment walkthrough.
