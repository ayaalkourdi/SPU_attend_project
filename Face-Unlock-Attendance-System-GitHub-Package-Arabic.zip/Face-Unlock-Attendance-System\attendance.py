import hashlib
import hmac
import json
import re
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime


def now_iso():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def normalized_iso(value):
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=datetime.now().astimezone().tzinfo)
    return parsed.astimezone().isoformat(timespec="seconds")


class AttendanceStore:
    def __init__(self, path, minimum_presence_ratio=0.9, audit_key=""):
        self.path = path
        self.minimum_presence_ratio = float(minimum_presence_ratio)
        self.audit_key = audit_key.encode("utf-8")
        self.lock = threading.RLock()
        self.initialize()

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=20)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA journal_mode=WAL")
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def initialize(self):
        with self.connect() as db:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS students (
              id INTEGER PRIMARY KEY,
              name TEXT NOT NULL UNIQUE,
              active INTEGER NOT NULL DEFAULT 1,
              created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS lectures (
              id INTEGER PRIMARY KEY,
              name TEXT NOT NULL,
              starts_at TEXT NOT NULL,
              ends_at TEXT NOT NULL,
              status TEXT NOT NULL DEFAULT 'scheduled',
              created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS events (
              id INTEGER PRIMARY KEY,
              lecture_id INTEGER,
              student_id INTEGER NOT NULL,
              direction TEXT NOT NULL CHECK(direction IN ('entry','exit')),
              occurred_at TEXT NOT NULL,
              confidence REAL,
              camera_index INTEGER,
              FOREIGN KEY(lecture_id) REFERENCES lectures(id),
              FOREIGN KEY(student_id) REFERENCES students(id)
            );
            CREATE TABLE IF NOT EXISTS attendance (
              lecture_id INTEGER NOT NULL,
              student_id INTEGER NOT NULL,
              entry_at TEXT,
              exit_at TEXT,
              presence_ratio REAL NOT NULL DEFAULT 0,
              result TEXT NOT NULL,
              PRIMARY KEY(lecture_id, student_id),
              FOREIGN KEY(lecture_id) REFERENCES lectures(id),
              FOREIGN KEY(student_id) REFERENCES students(id)
            );
            CREATE INDEX IF NOT EXISTS idx_events_lookup
              ON events(lecture_id, student_id, direction, occurred_at);
            CREATE TABLE IF NOT EXISTS audit_log (
              sequence INTEGER PRIMARY KEY AUTOINCREMENT,
              created_at TEXT NOT NULL,
              actor TEXT NOT NULL,
              action TEXT NOT NULL,
              entity_type TEXT NOT NULL,
              entity_id TEXT,
              payload_json TEXT NOT NULL,
              previous_hash TEXT NOT NULL,
              entry_hash TEXT NOT NULL UNIQUE
            );
            """)
            self.add_column(db, "students", "university_id TEXT")
            self.add_column(db, "events", "source TEXT NOT NULL DEFAULT 'legacy'")
            self.add_column(db, "events", "model_version TEXT")
            self.add_column(db, "events", "event_hash TEXT")
            self.add_column(db, "events", "created_at TEXT")
            self.add_column(db, "attendance", "session_count INTEGER NOT NULL DEFAULT 0")
            self.add_column(db, "attendance", "gap_seconds REAL NOT NULL DEFAULT 0")
            db.execute(
                """CREATE UNIQUE INDEX IF NOT EXISTS idx_students_university_id
                   ON students(university_id) WHERE university_id IS NOT NULL"""
            )
            db.execute(
                """CREATE UNIQUE INDEX IF NOT EXISTS idx_events_event_hash
                   ON events(event_hash) WHERE event_hash IS NOT NULL"""
            )

    @staticmethod
    def add_column(db, table, definition):
        column = definition.split()[0]
        existing = {row[1] for row in db.execute(f"PRAGMA table_info({table})")}
        if column not in existing:
            db.execute(f"ALTER TABLE {table} ADD COLUMN {definition}")

    def append_audit(self, db, actor, action, entity_type, entity_id, payload):
        previous = db.execute(
            "SELECT entry_hash FROM audit_log ORDER BY sequence DESC LIMIT 1"
        ).fetchone()
        previous_hash = previous["entry_hash"] if previous else "GENESIS"
        created_at = now_iso()
        payload_json = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        material = "|".join((
            previous_hash, created_at, actor, action, entity_type,
            str(entity_id or ""), payload_json,
        )).encode("utf-8")
        entry_hash = hmac.new(self.audit_key, material, hashlib.sha256).hexdigest()
        db.execute(
            """INSERT INTO audit_log(
                 created_at,actor,action,entity_type,entity_id,payload_json,
                 previous_hash,entry_hash
               ) VALUES(?,?,?,?,?,?,?,?)""",
            (created_at, actor, action, entity_type, str(entity_id or ""),
             payload_json, previous_hash, entry_hash),
        )
        return entry_hash

    def verify_audit(self):
        previous_hash = "GENESIS"
        with self.connect() as db:
            rows = db.execute("SELECT * FROM audit_log ORDER BY sequence").fetchall()
        for row in rows:
            material = "|".join((
                previous_hash, row["created_at"], row["actor"], row["action"],
                row["entity_type"], row["entity_id"], row["payload_json"],
            )).encode("utf-8")
            expected = hmac.new(self.audit_key, material, hashlib.sha256).hexdigest()
            if row["previous_hash"] != previous_hash or not hmac.compare_digest(
                row["entry_hash"], expected
            ):
                return {"valid": False, "entries": len(rows), "failed_sequence": row["sequence"]}
            previous_hash = row["entry_hash"]
        return {"valid": True, "entries": len(rows)}

    def rowdicts(self, rows):
        return [dict(row) for row in rows]

    def ensure_student(self, name):
        with self.lock, self.connect() as db:
            db.execute(
                "INSERT OR IGNORE INTO students(name,created_at) VALUES(?,?)",
                (name, now_iso()),
            )
            return db.execute("SELECT id FROM students WHERE name=?", (name,)).fetchone()["id"]

    def validate_new_student(self, name, university_id):
        with self.connect() as db:
            if db.execute("SELECT 1 FROM students WHERE name=?", (name,)).fetchone():
                raise ValueError("A student with this name already exists")
            if db.execute(
                "SELECT 1 FROM students WHERE university_id=?", (university_id,)
            ).fetchone():
                raise ValueError("This university ID is already registered")

    def register_student(self, name, university_id):
        with self.lock, self.connect() as db:
            self.validate_new_student(name, university_id)
            cur = db.execute(
                """INSERT INTO students(name,university_id,created_at)
                   VALUES(?,?,?)""",
                (name, university_id, now_iso()),
            )
            student_id = cur.lastrowid
            self.append_audit(
                db, "admin", "student_registered", "student", student_id,
                {"name": name, "university_id": university_id},
            )
            return student_id

    def set_university_id(self, student_id, university_id):
        university_id = str(university_id).strip().upper()
        if not re.fullmatch(r"[A-Z0-9_-]{3,30}", university_id):
            raise ValueError(
                "University ID must be 3–30 letters, numbers, underscores or hyphens"
            )
        with self.lock, self.connect() as db:
            student = db.execute(
                "SELECT id,name,university_id FROM students WHERE id=?", (student_id,)
            ).fetchone()
            if not student:
                raise ValueError("student not found")
            duplicate = db.execute(
                "SELECT id FROM students WHERE university_id=? AND id!=?",
                (university_id, student_id),
            ).fetchone()
            if duplicate:
                raise ValueError("This university ID is already registered")
            db.execute(
                "UPDATE students SET university_id=? WHERE id=?",
                (university_id, student_id),
            )
            self.append_audit(
                db, "admin", "university_id_changed", "student", student_id,
                {
                    "name": student["name"],
                    "previous_university_id": student["university_id"],
                    "university_id": university_id,
                },
            )
            return {"id": student_id, "university_id": university_id}

    def sync_students(self, names):
        for name in names:
            self.ensure_student(name)

    def active_lecture(self, when=None):
        when = normalized_iso(when) if when else now_iso()
        with self.connect() as db:
            row = db.execute(
                """SELECT * FROM lectures
                   WHERE starts_at<=? AND ends_at>=? AND status!='finalized'
                   ORDER BY starts_at DESC LIMIT 1""",
                (when, when),
            ).fetchone()
            return dict(row) if row else None

    def add_lecture(self, name, starts_at, ends_at):
        name = " ".join(str(name).strip().split())
        if not name or len(name) > 120:
            raise ValueError("Lecture name is required and must be under 120 characters")
        starts_at = normalized_iso(starts_at)
        ends_at = normalized_iso(ends_at)
        if datetime.fromisoformat(ends_at) <= datetime.fromisoformat(starts_at):
            raise ValueError("ends_at must be after starts_at")
        with self.lock, self.connect() as db:
            overlap = db.execute(
                """SELECT 1 FROM lectures
                   WHERE status!='finalized' AND starts_at<? AND ends_at>? LIMIT 1""",
                (ends_at, starts_at),
            ).fetchone()
            if overlap:
                raise ValueError("Lecture time overlaps an existing lecture")
            cur = db.execute(
                "INSERT INTO lectures(name,starts_at,ends_at,created_at) VALUES(?,?,?,?)",
                (name, starts_at, ends_at, now_iso()),
            )
            self.append_audit(
                db, "admin", "lecture_created", "lecture", cur.lastrowid,
                {"name": name, "starts_at": starts_at, "ends_at": ends_at},
            )
            return cur.lastrowid

    def record_camera_event(self, student_name, direction, confidence, camera_index,
                            model_version, evidence_hash):
        if direction not in ("entry", "exit"):
            raise ValueError("direction must be entry or exit")
        occurred_at = now_iso()
        lecture = self.active_lecture(occurred_at)
        with self.lock, self.connect() as db:
            student = db.execute(
                "SELECT id FROM students WHERE name=? AND active=1", (student_name,)
            ).fetchone()
            if not student:
                raise ValueError("recognized identity is not an active registered student")
            student_id = student["id"]
            cur = db.execute(
                """INSERT INTO events(
                     lecture_id,student_id,direction,occurred_at,confidence,camera_index,
                     source,model_version,created_at
                   ) VALUES(?,?,?,?,?,?,?,?,?)""",
                (lecture["id"] if lecture else None, student_id, direction,
                 occurred_at, confidence, camera_index, "camera", model_version, now_iso()),
            )
            event_id = cur.lastrowid
            event_hash = self.append_audit(
                db, f"camera:{camera_index}", "face_event", "event", event_id,
                {
                    "student_id": student_id,
                    "direction": direction,
                    "occurred_at": occurred_at,
                    "confidence": round(float(confidence), 4),
                    "camera_index": int(camera_index),
                    "model_version": model_version,
                    "evidence_hash": evidence_hash,
                    "lecture_id": lecture["id"] if lecture else None,
                },
            )
            db.execute("UPDATE events SET event_hash=? WHERE id=?", (event_hash, event_id))
        return {"id": event_id, "lecture_id": lecture["id"] if lecture else None}

    def finalize(self, lecture_id):
        with self.lock, self.connect() as db:
            lecture = db.execute("SELECT * FROM lectures WHERE id=?", (lecture_id,)).fetchone()
            if not lecture:
                raise ValueError("lecture not found")
            if lecture["status"] == "finalized":
                raise ValueError("lecture is already finalized")
            start = datetime.fromisoformat(lecture["starts_at"])
            end = datetime.fromisoformat(lecture["ends_at"])
            if datetime.now().astimezone() < end:
                raise ValueError("lecture cannot be finalized before its end time")
            duration = max((end - start).total_seconds(), 1)
            students = db.execute("SELECT id FROM students WHERE active=1").fetchall()
            for student in students:
                sid = student["id"]
                events = db.execute(
                    """SELECT direction,occurred_at FROM events
                       WHERE lecture_id=? AND student_id=?
                       ORDER BY occurred_at,id""",
                    (lecture_id, sid),
                ).fetchall()
                sessions = []
                open_entry = None
                for event in events:
                    event_time = datetime.fromisoformat(event["occurred_at"])
                    if event["direction"] == "entry" and open_entry is None:
                        open_entry = max(event_time, start)
                    elif event["direction"] == "exit" and open_entry is not None:
                        closed_at = min(event_time, end)
                        if closed_at > open_entry:
                            sessions.append((open_entry, closed_at))
                        open_entry = None
                entry = sessions[0][0].isoformat(timespec="seconds") if sessions else None
                exit_ = sessions[-1][1].isoformat(timespec="seconds") if sessions else None
                presence_seconds = sum((closed - opened).total_seconds() for opened, closed in sessions)
                ratio = max(0.0, min(1.0, presence_seconds / duration))
                if not events or not any(event["direction"] == "entry" for event in events):
                    result = "missing_entry"
                elif open_entry is not None or not sessions:
                    result = "missing_exit"
                else:
                    result = "completed" if ratio >= self.minimum_presence_ratio else "insufficient_duration"
                db.execute(
                    """INSERT INTO attendance(
                         lecture_id,student_id,entry_at,exit_at,presence_ratio,result,
                         session_count,gap_seconds
                       ) VALUES(?,?,?,?,?,?,?,?)
                       ON CONFLICT(lecture_id,student_id) DO UPDATE SET
                       entry_at=excluded.entry_at,exit_at=excluded.exit_at,
                       presence_ratio=excluded.presence_ratio,result=excluded.result,
                       session_count=excluded.session_count,gap_seconds=excluded.gap_seconds""",
                    (lecture_id, sid, entry, exit_, ratio, result, len(sessions),
                     max(0.0, duration - presence_seconds)),
                )
            db.execute("UPDATE lectures SET status='finalized' WHERE id=?", (lecture_id,))
            self.append_audit(
                db, "admin", "lecture_finalized", "lecture", lecture_id,
                {"student_count": len(students), "minimum_presence_ratio": self.minimum_presence_ratio},
            )
        return self.results(lecture_id)

    def lectures(self):
        with self.connect() as db:
            return self.rowdicts(db.execute("SELECT * FROM lectures ORDER BY starts_at DESC").fetchall())

    def students(self):
        with self.connect() as db:
            return self.rowdicts(db.execute(
                """SELECT s.id,s.name,s.university_id,s.active,s.created_at,
                          COUNT(e.id) event_count,MAX(e.occurred_at) last_seen
                   FROM students s LEFT JOIN events e ON e.student_id=s.id
                   GROUP BY s.id ORDER BY s.name"""
            ).fetchall())

    def summary(self):
        with self.connect() as db:
            return {
                "students": db.execute("SELECT COUNT(*) FROM students WHERE active=1").fetchone()[0],
                "lectures": db.execute("SELECT COUNT(*) FROM lectures").fetchone()[0],
                "events": db.execute("SELECT COUNT(*) FROM events").fetchone()[0],
                "completed": db.execute(
                    "SELECT COUNT(*) FROM attendance WHERE result='completed'"
                ).fetchone()[0],
            }

    def all_results(self, limit=500):
        with self.connect() as db:
            return self.rowdicts(db.execute(
                """SELECT a.*,s.name student_name,l.name lecture_name
                   FROM attendance a JOIN students s ON s.id=a.student_id
                   JOIN lectures l ON l.id=a.lecture_id
                   ORDER BY l.starts_at DESC,s.name LIMIT ?""", (limit,)
            ).fetchall())

    def recent_events(self, limit=100):
        with self.connect() as db:
            return self.rowdicts(db.execute(
                """SELECT e.*,s.name student_name,l.name lecture_name
                   FROM events e JOIN students s ON s.id=e.student_id
                   LEFT JOIN lectures l ON l.id=e.lecture_id
                   ORDER BY e.occurred_at DESC LIMIT ?""", (limit,)
            ).fetchall())

    def results(self, lecture_id):
        with self.connect() as db:
            return self.rowdicts(db.execute(
                """SELECT a.*,s.name student_name,l.name lecture_name
                   FROM attendance a JOIN students s ON s.id=a.student_id
                   JOIN lectures l ON l.id=a.lecture_id
                   WHERE a.lecture_id=? ORDER BY s.name""", (lecture_id,)
            ).fetchall())
