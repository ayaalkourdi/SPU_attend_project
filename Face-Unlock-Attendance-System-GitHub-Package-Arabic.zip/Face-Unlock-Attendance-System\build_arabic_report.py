from datetime import date
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


OUT = Path(r"C:\Users\yamen\Documents\faceapp\توثيق_مشروع_الحضور_DeepFace.docx")
NAVY = "15245A"
BLUE = "192E76"
RED = "C8202E"
LIGHT = "F1F2F4"
LINE = "D7D7DE"
GRAY = "5F5E5E"
WHITE = "FFFFFF"
FONT = "Arial"


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_width(cell, width_dxa):
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_w = tc_pr.find(qn("w:tcW"))
    if tc_w is None:
        tc_w = OxmlElement("w:tcW")
        tc_pr.append(tc_w)
    tc_w.set(qn("w:w"), str(width_dxa))
    tc_w.set(qn("w:type"), "dxa")


def rtl_paragraph(p, align=WD_ALIGN_PARAGRAPH.RIGHT):
    p.alignment = align
    p_pr = p._p.get_or_add_pPr()
    bidi = p_pr.find(qn("w:bidi"))
    if bidi is None:
        bidi = OxmlElement("w:bidi")
        p_pr.append(bidi)
    bidi.set(qn("w:val"), "1")


def format_run(run, size=11, color=None, bold=None):
    run.font.name = FONT
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), FONT)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), FONT)
    run._element.get_or_add_rPr().rFonts.set(qn("w:cs"), FONT)
    run.font.size = Pt(size)
    run._element.get_or_add_rPr().set(qn("w:rtl"), "1")
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    if bold is not None:
        run.bold = bold


def add_p(doc, text="", bold=False, color=None, size=11, after=6, style=None):
    p = doc.add_paragraph(style=style)
    rtl_paragraph(p)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.line_spacing = 1.25
    r = p.add_run(text)
    format_run(r, size=size, color=color, bold=bold)
    return p


def add_heading(doc, text, level=1):
    p = doc.add_paragraph(style=f"Heading {level}")
    rtl_paragraph(p)
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text)
    format_run(r, size={1: 16, 2: 13, 3: 12}[level],
               color=NAVY if level < 3 else BLUE, bold=True)
    return p


def add_bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    rtl_paragraph(p)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.2
    format_run(p.add_run(text), size=10.5)
    return p


def add_step(doc, title, body):
    p = doc.add_paragraph(style="List Number")
    rtl_paragraph(p)
    p.paragraph_format.space_after = Pt(7)
    p.paragraph_format.line_spacing = 1.22
    format_run(p.add_run(title + ": "), size=11, color=RED, bold=True)
    format_run(p.add_run(body), size=11)
    return p


def add_note(doc, title, text):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    cell = table.cell(0, 0)
    set_cell_width(cell, 9360)
    set_cell_shading(cell, "EEF1F8")
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    p = cell.paragraphs[0]
    rtl_paragraph(p)
    format_run(p.add_run(title + ": "), size=10.5, color=NAVY, bold=True)
    format_run(p.add_run(text), size=10.5)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def add_table(doc, headers, rows, widths):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    table.style = "Table Grid"
    for idx, (header, width) in enumerate(zip(headers, widths)):
        cell = table.rows[0].cells[idx]
        set_cell_width(cell, width)
        set_cell_shading(cell, NAVY)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        p = cell.paragraphs[0]
        rtl_paragraph(p, WD_ALIGN_PARAGRAPH.CENTER)
        format_run(p.add_run(header), size=9.5, color=WHITE, bold=True)
    for row_data in rows:
        cells = table.add_row().cells
        for idx, (value, width) in enumerate(zip(row_data, widths)):
            set_cell_width(cells[idx], width)
            cells[idx].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            p = cells[idx].paragraphs[0]
            rtl_paragraph(p)
            format_run(p.add_run(str(value)), size=9.2)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return table


doc = Document()
section = doc.sections[0]
section.page_width = Inches(8.5)
section.page_height = Inches(11)
section.top_margin = Inches(0.85)
section.bottom_margin = Inches(0.8)
section.left_margin = Inches(0.85)
section.right_margin = Inches(0.85)
section.header_distance = Inches(0.35)
section.footer_distance = Inches(0.35)

styles = doc.styles
normal = styles["Normal"]
normal.font.name = FONT
normal.font.size = Pt(11)
normal._element.rPr.rFonts.set(qn("w:ascii"), FONT)
normal._element.rPr.rFonts.set(qn("w:hAnsi"), FONT)
normal._element.rPr.rFonts.set(qn("w:cs"), FONT)
normal.paragraph_format.space_after = Pt(6)
normal.paragraph_format.line_spacing = 1.25
for level, size in [(1, 16), (2, 13), (3, 12)]:
    st = styles[f"Heading {level}"]
    st.font.name = FONT
    st.font.size = Pt(size)
    st.font.bold = True
    st.font.color.rgb = RGBColor.from_string(NAVY if level < 3 else BLUE)
    st.paragraph_format.space_before = Pt({1: 16, 2: 12, 3: 8}[level])
    st.paragraph_format.space_after = Pt({1: 8, 2: 6, 3: 4}[level])

# Running header/footer
hp = section.header.paragraphs[0]
rtl_paragraph(hp)
format_run(hp.add_run("نظام الحضور بالتعرّف على الوجه | التوثيق التقني"), 8.5, NAVY, True)
fp = section.footer.paragraphs[0]
rtl_paragraph(fp, WD_ALIGN_PARAGRAPH.CENTER)
format_run(fp.add_run("تقرير التنفيذ والتشغيل"), 8.5, GRAY)
format_run(fp.add_run("  |  صفحة "), 8.5, GRAY)
fld = OxmlElement("w:fldSimple")
fld.set(qn("w:instr"), "PAGE")
fp._p.append(fld)

# Cover
for _ in range(4):
    doc.add_paragraph()
p = doc.add_paragraph()
rtl_paragraph(p, WD_ALIGN_PARAGRAPH.CENTER)
format_run(p.add_run("تقرير مشروع نظام الحضور بالتعرّف على الوجه"), 24, NAVY, True)
p = doc.add_paragraph()
rtl_paragraph(p, WD_ALIGN_PARAGRAPH.CENTER)
format_run(p.add_run("DeepFace · SFace · YuNet · Raspberry Pi 5 · لوحة تحكم إدارية"), 13, GRAY)
for _ in range(4):
    doc.add_paragraph()
p = doc.add_paragraph()
rtl_paragraph(p, WD_ALIGN_PARAGRAPH.CENTER)
format_run(p.add_run("نسخة توثيقية شاملة - 26 تموز 2026"), 11, RED, True)
doc.add_page_break()

add_heading(doc, "ملخص تنفيذي", 1)
add_p(doc, "تم تحويل جهاز Raspberry Pi 5 إلى منصة حضور تعمل تلقائيًا باستخدام إطار DeepFace. يكتشف YuNet الوجه ويحاذيه، ويولد نموذج SFace تضمينًا عدديًا من 128 بُعدًا، ثم يقارن النظام التضمين بمراجع الطلاب باستخدام Cosine Distance. يسجل الدخول والخروج في SQLite، ويحسب نتيجة الحضور بعد المحاضرة، ويوفر لوحة إدارية وبثًا مباشرًا.")
add_note(doc, "الوضع الحالي", "الخدمة تعمل تلقائيًا عند إقلاع الجهاز. الكاميرا رقم 0 تعمل ككاميرا دخول، بينما الكاميرا رقم 1 غير مكتشفة حاليًا وتحتاج إلى توصيلها أو معالجة عتادها قبل اختبار الخروج فعليًا.")

add_heading(doc, "محتويات التقرير", 1)
for item in [
    "الوضع الأولي وفحص الجهاز", "القرارات التقنية وأسبابها", "بناء قاعدة البيانات ومنطق الحضور",
    "التعرف على الوجه وتسجيل الطلاب", "لوحة التحكم الإدارية والبث المباشر",
    "التشغيل التلقائي والشبكة", "دليل التشغيل اليومي", "الملفات والمسارات",
    "البدائل التي كانت متاحة", "المشكلات المفتوحة والتوصيات",
]:
    add_bullet(doc, item)

add_heading(doc, "1. نقطة البداية وفحص الجهاز", 1)
add_p(doc, "بدأ العمل من مستودع محلي فارغ تقريبًا، لذلك اعتُمد وصف المشروع الذي قدمه المستخدم كمصدر المتطلبات. تم الاتصال بالجهاز عبر SSH وفحص النظام والعتاد والبرمجيات قبل إجراء أي تعديل.")
add_table(doc, ["العنصر", "النتيجة"], [
    ("الجهاز", "Raspberry Pi 5 بذاكرة 8GB"),
    ("نظام التشغيل", "Debian GNU/Linux 13 (trixie)، معمارية ARM64"),
    ("اسم الجهاز", "Senior1"),
    ("عنوان الشبكة المحلية", "192.168.50.89"),
    ("عنوان WireGuard VPN", "10.10.0.8/24 على الواجهة wg0"),
    ("التخزين عند الفحص", "نحو 47GB متاحة"),
    ("الكاميرات", "كاميرا IMX219 واحدة مكتشفة؛ الثانية غير مكتشفة"),
    ("Python", "الإصدار 3.13.5"),
    ("المكتبات الجاهزة", "OpenCV، Picamera2، Flask، NumPy"),
], [2600, 6760])
add_p(doc, "لماذا بدأنا بالفحص؟ لأن تثبيت حزم ذكاء اصطناعي كبيرة أو افتراض وجود كاميرتين دون تحقق كان قد يؤدي إلى تعطيل الجهاز أو اختيار تقنية غير متوافقة.")

add_heading(doc, "2. تقييم المشروع القديم", 1)
add_p(doc, "وُجد مشروع سابق في المسار /home/senior/face_project يحتوي على نموذج LBPH مدرب وأربع هويات باسم person1 إلى person4، إضافة إلى صور التدريب وبرامج قديمة بواجهة Tkinter.")
add_bullet(doc, "تم الحفاظ على المشروع القديم وعدم حذفه.")
add_bullet(doc, "استُخدمت صور التدريب السابقة لإنشاء 85 تضمين DeepFace لأربع هويات، دون الاعتماد على نموذج LBPH أثناء التشغيل.")
add_bullet(doc, "أُنشئ النظام الجديد في مجلد مستقل: /home/senior/attendance-system.")

add_heading(doc, "3. محرك التعرّف الحالي: DeepFace", 1)
add_p(doc, "المتطلب النهائي هو استخدام DeepFace. أُنشئت بيئة Python افتراضية معزولة داخل المشروع وثُبت فيها DeepFace 0.0.100 وTensorFlow 2.21.0 وtf-keras 2.21.0 بإصدارات ARM64 المتوافقة مع Python 3.13. بقي نظام Raspberry Pi الأساسي دون تعديل للحزم المدارة من Debian.")
add_table(doc, ["الخيار", "المزايا", "السلبيات", "القرار"], [
    ("DeepFace + SFace", "تضمينات حديثة، سريع على Pi، مقارنة مرنة", "بيئة أكبر من LBPH وتحتاج ملفات أوزان", "الخيار الحالي"),
    ("DeepFace + Facenet512", "تضمينات قوية وشائعة", "أثقل وأبطأ على CPU", "بديل لاحق"),
    ("OpenCV LBPH", "خفيف وبسيط", "أقل ثباتًا مع الزوايا والإضاءة", "متقاعد"),
    ("خادم تعرّف خارجي", "قدرة أعلى وإدارة مركزية", "يحتاج شبكة ويرفع اعتبارات الخصوصية", "بديل عند التوسع"),
], [1800, 2500, 3160, 1900])

add_heading(doc, "كيف يعمل DeepFace مع SFace؟", 2)
add_p(doc, "DeepFace هو إطار يوحد مراحل التعرف: الكشف، المحاذاة، التطبيع، التمثيل والمقارنة. في هذا المشروع يستخدم YuNet للكشف وSFace للتمثيل. لا يقارن النظام الصور بكسلًا ببكسل؛ بل يحول كل وجه إلى متجه عددي يصف خصائصه.")
for text in [
    "يكتشف YuNet حدود الوجه ونقاطًا مرجعية مثل العينين والأنف والفم.",
    "تستخدم DeepFace نقاط الوجه لمحاذاة الصورة وتقليل أثر ميلان الرأس.",
    "تُطبّع صورة الوجه ثم تمر عبر SFace لإنتاج متجه من 128 قيمة.",
    "يُطبّع المتجه L2 حتى تصبح المقارنة مستقرة بين الصور.",
    "تُحسب Cosine Distance بين متجه اللقطة وكل متجه مرجعي مخزن.",
    "تُختار أقل مسافة؛ يُقبل الاسم فقط إذا كانت المسافة أقل من أو تساوي 0.40.",
]:
    add_bullet(doc, text)
add_note(doc, "معنى المسافة", "Cosine Distance الأصغر تعني تشابهًا أكبر. قيمة التشابه المعروضة في اللوحة هي تحويل مفهوم للمستخدم وليست احتمالًا إحصائيًا. قرار القبول الحقيقي يعتمد على distance_threshold.")

add_heading(doc, "مسار اللقطة من الكاميرا إلى حدث حضور", 2)
add_step(doc, "التقاط الإطار", "Picamera2 يلتقط صورة XRGB8888 بدقة 640×480 من الكاميرا المحددة.")
add_step(doc, "كشف الوجه", "OpenCV يحول الإطار إلى رمادي ويبحث عن الوجوه بواسطة Haar Cascade.")
add_step(doc, "التمثيل", "DeepFace يحاذي الوجه ويولد تضمين SFace من 128 بُعدًا.")
add_step(doc, "المقارنة", "يُقارن التضمين مع 85 مرجعًا باستخدام Cosine Distance ويُختار أقرب اسم.")
add_step(doc, "التحقق الزمني", "يجب تكرار الاسم نفسه في عدد متتالٍ من الإطارات recognition_streak قبل قبول الحدث.")
add_step(doc, "منع التكرار", "event_cooldown_seconds يمنع حفظ دخول أو خروج متكرر للشخص نفسه خلال فترة قصيرة.")
add_step(doc, "الحفظ", "يستدعي عامل الكاميرا AttendanceStore لربط الحدث بالطالب والمحاضرة النشطة وكتابته في SQLite.")
add_step(doc, "تحديث الواجهة", "لوحة التحكم تطلب البيانات من API دوريًا وتعرض الحدث الجديد دون إعادة تحميل الصفحة.")

add_heading(doc, "المعايرة والدقة", 2)
add_p(doc, "لم تُستخدم عتبة DeepFace العامة مباشرة. أظهرت معايرة البيانات الحالية أن أكبر مسافة داخل الشخص نفسه 0.347، وأن أصغر مسافة بين شخصين مختلفين 0.444. لذلك اختيرت 0.40 كفاصل بين المجموعتين. يجب إعادة المعايرة عند إضافة بيانات كثيرة أو تغيير بيئة التصوير.")
add_table(doc, ["المقياس", "المعنى", "كيفية القياس"], [
    ("False Accept", "اعتبار شخص غير مسجل طالبًا مسجلًا", "اختبار أشخاص خارج قاعدة البيانات وتسجيل المسافات."),
    ("False Reject", "رفض الطالب الصحيح", "اختبار كل طالب تحت زوايا وإضاءات مختلفة."),
    ("Recognition latency", "الزمن بين ظهور الوجه وتسجيل الحدث", "زمن DeepFace بعد الإحماء نحو 71ms للصورة؛ البث الاختباري قرابة 12FPS."),
], [2100, 3060, 4200])

add_heading(doc, "4. بناء النظام الجديد خطوة بخطوة", 1)
add_step(doc, "إنشاء بنية التطبيق", "فُصلت الكاميرات، قاعدة البيانات، التسجيل والتدريب، ولوحة التحكم إلى ملفات مستقلة لتسهيل الصيانة والاختبار.")
add_step(doc, "إنشاء قاعدة SQLite", "أُنشئت جداول الطلاب والمحاضرات وأحداث الدخول والخروج ونتائج الحضور، مع تفعيل WAL لتحسين العمل المتزامن.")
add_step(doc, "تعريف دور الكاميرات", "الكاميرا 0 للدخول والكاميرا 1 للخروج. يكتشف البرنامج عدد الكاميرات عند التشغيل ويبلغ عن أي كاميرا مفقودة.")
add_step(doc, "تثبيت التسجيل الذكي", "لا يُسجل الوجه من لقطة واحدة؛ يجب ظهوره لعدة لقطات متتالية، ثم يُطبق وقت تهدئة لمنع تكرار الحدث بسرعة.")
add_step(doc, "ربط الحدث بالمحاضرة", "إذا وقع الحدث داخل وقت محاضرة نشطة يرتبط بها؛ وإلا يُحفظ كحدث خارج المحاضرة.")
add_step(doc, "حساب النتيجة", "بعد إنهاء المحاضرة، يبحث النظام عن أول دخول وآخر خروج ويحسب نسبة مدة البقاء إلى مدة المحاضرة.")
add_step(doc, "توفير API ولوحة ويب", "أُنشئت واجهات للطلاب والمحاضرات والأحداث والنتائج والحالة، ثم رُبطت بلوحة إدارة تتحدث دوريًا.")
add_step(doc, "إضافة التشغيل التلقائي", "ثُبتت خدمة systemd باسم face-attendance لتعمل عند الإقلاع وتُعاد تلقائيًا عند الخطأ.")

add_heading(doc, "5. منطق الحضور", 1)
add_p(doc, "النتيجة النهائية لا تعتمد على ظهور الوجه مرة واحدة فقط. تُحسب بعد إنهاء المحاضرة وفق الحالات التالية:")
add_table(doc, ["النتيجة", "المعنى"], [
    ("completed", "يوجد دخول وخروج صحيحان وتغطي مدة البقاء النسبة المطلوبة من المحاضرة."),
    ("missing_entry", "لا يوجد تسجيل دخول خلال المحاضرة."),
    ("missing_exit", "يوجد دخول لكن لا يوجد خروج."),
    ("insufficient_duration", "يوجد دخول وخروج، لكن مدة البقاء أقل من الحد المطلوب."),
], [2800, 6560])
add_note(doc, "قيد مهم", "كاميرتا الباب تثبتان وقت الدخول والخروج، لكنهما لا تثبتان بشكل مباشر وجود الطالب داخل القاعة في كل لحظة. للتحقق المستمر فعلًا يمكن إضافة كاميرا داخلية أو نقاط تحقق دورية.")

add_heading(doc, "6. تسجيل طالب جديد من لوحة التحكم", 1)
add_p(doc, "أُضيف نموذج إداري يطلب اسم الطالب و20 إلى 30 صورة. تتم العملية كما يلي:")
for text in [
    "فحص العدد قبل الرفع: لا يقل عن 20 ولا يزيد على 30.",
    "فك ترميز كل صورة والتحقق من احتوائها على وجه واحد واضح فقط.",
    "رفض الصور الفارغة أو التالفة أو التي لا تحتوي وجهًا واحدًا.",
    "اشتراط بقاء 20 صورة صالحة على الأقل بعد الفحص.",
    "حفظ الصور في مجلد مؤقت ثم نقلها إلى مجموعة البيانات بعد نجاح التحقق.",
    "توليد تضمين DeepFace مستقل لكل صورة مقبولة بدل تدريب مصنف جديد.",
    "كتابة مصفوفة التضمينات والأسماء إلى ملف NPZ مؤقت ثم استبدال الفهرس الحالي وإعادة تحميله دون إعادة تشغيل.",
]:
    add_bullet(doc, text)
add_p(doc, "DeepFace يعمل بأسلوب التضمينات وOne-shot Recognition؛ لذلك لا يحتاج إلى تدريب الشبكة العصبية عند كل طالب. إعادة البناء تعني استخراج مراجع جديدة لكل الطلاب وحفظها في deepface_embeddings.npz. الاستبدال المؤقت يمنع ترك فهرس ناقص عند الخطأ.")

add_heading(doc, "7. لوحة التحكم الإدارية", 1)
add_p(doc, "العنوان المحلي للوحة هو http://192.168.50.89:5000، وعبر الـVPN هو http://10.10.0.8:5000. يجب فتح أحد هذين العنوانين، وليس ملف dashboard.html المحلي.")
add_table(doc, ["القسم", "ما يعرضه أو ينفذه"], [
    ("Live Cameras", "البث المباشر للكاميرات المكتشفة مع رقم الكاميرا ودورها ونتيجة التعرف."),
    ("Students", "قائمة الطلاب، الحالة، عدد الأحداث، آخر ظهور، وتسجيل طالب جديد."),
    ("Lectures", "إنشاء محاضرة بوقت بداية ونهاية، عرض المحاضرات، وإنهاء المحاضرة."),
    ("Entry / Exit", "كل أحداث التعرف مع الاتجاه والوقت والكاميرا والثقة والمحاضرة."),
    ("Attendance Results", "الدخول والخروج ونسبة الحضور والنتيجة النهائية لكل طالب."),
    ("Summary", "إجمالي الطلاب والمحاضرات والأحداث والحضور المكتمل."),
], [2500, 6860])

add_heading(doc, "بنية لوحة التحكم وتدفق البيانات", 2)
add_p(doc, "الواجهة ليست مرتبطة بقاعدة البيانات مباشرة. المتصفح يرسل طلبات HTTP إلى Flask، وFlask يستدعي AttendanceStore، ثم يعيد JSON. هذا الفصل يمنع كشف ملف SQLite للمتصفح ويتيح إضافة صلاحيات وتدقيق لاحقًا.")
add_table(doc, ["الطبقة", "مسؤوليتها"], [
    ("dashboard.html", "عرض الأقسام والجداول والنماذج والبث، وإرسال fetch إلى API كل خمس ثوانٍ."),
    ("Flask / app.py", "التحقق من الطلبات، تشغيل الكاميرات، تقديم JSON وMJPEG، وتنسيق المكونات."),
    ("AttendanceStore", "كل أوامر SQL والمعاملات وربط الطلاب والمحاضرات والأحداث."),
    ("CameraWorker", "حلقة الالتقاط والتعرف لكل كاميرا دون تعطيل خادم الويب."),
    ("EnrollmentManager", "فحص الصور واستخراج تضمينات DeepFace والاستبدال الذري للفهرس."),
], [2500, 6860])
add_p(doc, "يعالج Flask طلبات الويب بخيوط متعددة، ولكل كاميرا CameraWorker مستقل. توجد أقفال threading حول مصفوفة التضمينات أثناء المقارنة وreload، وحول إعادة بناء الفهرس، لمنع القراءة أثناء الاستبدال.")

add_heading(doc, "كيف تعمل أقسام لوحة التحكم؟", 2)
add_bullet(doc, "الملخص يجمع الأعداد مباشرة من قاعدة البيانات: الطلاب والمحاضرات والأحداث والنتائج المكتملة.")
add_bullet(doc, "Students يقرأ /api/students ويعرض عدد الأحداث وآخر ظهور، بينما نموذج الإضافة يرسل multipart/form-data.")
add_bullet(doc, "Lectures يرسل JSON لإنشاء محاضرة، وزر Finalize يستدعي الحساب النهائي ثم يعيد قراءة النتائج.")
add_bullet(doc, "Entry / Exit يعرض سجلًا زمنيًا لا يغير البيانات، مع الكاميرا والمسافة المحولة إلى ثقة تقريبية.")
add_bullet(doc, "Attendance Results يعرض نتيجة الجدول attendance بعد عملية finalize.")
add_bullet(doc, "Live Cameras يستخدم img مصدره مسار MJPEG؛ المتصفح يعرض سلسلة صور JPEG كفيديو مستمر.")

add_heading(doc, "8. البث المباشر", 1)
add_p(doc, "أُضيف بث MJPEG لكل كاميرا عبر مسار مستقل. لا يفتح البث الكاميرا مرة ثانية، بل يستخدم اللقطات نفسها التي يلتقطها عامل التعرف، لأن محاولة فتح كاميرا Pi من عمليتين قد تسبب تعارضًا.")
add_bullet(doc, "لا يتم ضغط JPEG إلا عند وجود مشاهد فعلي لتقليل الحمل على الجهاز.")
add_bullet(doc, "تظهر طبقة نصية فيها دور الكاميرا والاسم المكتشف ونسبة الثقة.")
add_bullet(doc, "تُبقي الصفحة الاتصال مفتوحًا ولا تعيد فتحه مع كل تحديث للبيانات.")

add_heading(doc, "9. قاعدة البيانات وكيفية فحصها", 1)
add_p(doc, "قاعدة البيانات موجودة في /home/senior/attendance-system/attendance.db. الملفات attendance.db-wal وattendance.db-shm ملفات عمل طبيعية لـSQLite ولا ينبغي حذفها أثناء تشغيل الخدمة.")
add_p(doc, "للفحص المباشر من الطرفية:")
add_note(doc, "الأمر", "cd /home/senior/attendance-system ثم python3 -m sqlite3 attendance.db")
for cmd in [".tables", "SELECT * FROM students;", "SELECT * FROM lectures;", "SELECT * FROM events;", "SELECT * FROM attendance;", ".quit"]:
    add_bullet(doc, cmd)
add_p(doc, "رغم إمكانية الفحص المباشر، عُرضت البيانات المهمة في لوحة الإدارة لتجنب تعديل القاعدة يدويًا بالخطأ.")

add_heading(doc, "10. التشغيل والخدمات", 1)
add_table(doc, ["الغرض", "الأمر"], [
    ("تشغيل يدوي", "cd /home/senior/attendance-system && python3 app.py"),
    ("حالة الخدمة", "sudo systemctl status face-attendance"),
    ("تشغيل الخدمة", "sudo systemctl start face-attendance"),
    ("إيقاف الخدمة", "sudo systemctl stop face-attendance"),
    ("إعادة التشغيل", "sudo systemctl restart face-attendance"),
    ("سجل الخدمة", "journalctl -u face-attendance -n 100 --no-pager"),
], [2600, 6760])
add_note(doc, "ملاحظة", "إذا ظهر أن المنفذ 5000 مستخدم عند التشغيل اليدوي، فهذا يعني غالبًا أن خدمة systemd تعمل بالفعل.")

add_heading(doc, "11. بنية الملفات الحالية", 1)
add_table(doc, ["المسار/الملف", "الدور"], [
    ("/home/senior/attendance-system/app.py", "خادم Flask، المسارات، API، بث الكاميرات وتشغيل العمال."),
    ("attendance.py", "بنية SQLite ومنطق الطلاب والمحاضرات والأحداث والنتائج."),
    ("cameras.py", "Picamera2، DeepFace/SFace/YuNet، مقارنة Cosine، التهدئة والبث."),
    ("enrollment.py", "رفع الصور والتحقق واستخراج التضمينات والاستبدال الذري للفهرس."),
    ("config.json", "إعدادات المنافذ والكاميرات والمسارات والعتبات."),
    ("templates/dashboard.html", "واجهة لوحة التحكم الإدارية."),
    ("attendance.db", "قاعدة بيانات التشغيل."),
    ("face-attendance.service", "تعريف خدمة التشغيل التلقائي."),
    ("/home/senior/face_project/dataset", "صور تدريب الطلاب."),
    ("/home/senior/attendance-system/deepface_embeddings.npz", "85 تضمينًا مرجعيًا وأسماء أصحابها."),
    ("/home/senior/attendance-system/.venv", "بيئة DeepFace وTensorFlow المعزولة."),
    ("/home/senior/.deepface/weights", "أوزان SFace وYuNet المحملة مسبقًا."),
], [3900, 5460])

add_heading(doc, "12. واجهات API الأساسية", 1)
add_table(doc, ["المسار", "الغرض"], [
    ("GET /api/status", "حالة الكاميرات والمحاضرة والملخص."),
    ("GET /api/students", "قائمة الطلاب."),
    ("POST /api/students", "تسجيل طالب بصور متعددة."),
    ("GET /api/lectures", "قائمة المحاضرات."),
    ("POST /api/lectures", "إنشاء محاضرة."),
    ("POST /api/lectures/{id}/finalize", "حساب النتائج وإنهاء المحاضرة."),
    ("GET /api/events", "أحداث الدخول والخروج."),
    ("GET /api/results", "النتائج النهائية."),
    ("GET /api/cameras/{id}/stream", "بث MJPEG للكاميرا."),
], [3900, 5460])

add_heading(doc, "13. بدائل معمارية كانت ممكنة", 1)
add_heading(doc, "13.1 واجهة سطح مكتب بدل الويب", 2)
add_p(doc, "كان يمكن تطوير Tkinter الموجود، لكنه يتطلب شاشة موصولة بالجهاز ويصعب فتحه من عدة أجهزة. اختير Flask لأن لوحة الويب تعمل من الهاتف أو الحاسوب عبر الشبكة.")
add_heading(doc, "13.2 قاعدة بيانات مركزية", 2)
add_p(doc, "كان يمكن استخدام PostgreSQL أو MySQL. SQLite أبسط لجهاز واحد ولا تحتاج خدمة إضافية. عند تشغيل عدة أجهزة أو فروع يفضل الانتقال إلى قاعدة مركزية.")
add_heading(doc, "13.3 عملية واحدة أو خدمات منفصلة", 2)
add_p(doc, "استُخدمت عملية تطبيق واحدة بخيوط للكاميرات لتقليل التعقيد. عند التوسع يمكن فصل التعرف، API، البث، والتدريب في خدمات مستقلة مع طابور رسائل.")
add_heading(doc, "13.4 التخزين السحابي", 2)
add_p(doc, "كان يمكن رفع الصور والنتائج إلى سحابة، لكن التخزين المحلي يحافظ على الخصوصية ويستمر دون إنترنت. النسخ الاحتياطي المشفر خيار مناسب لاحقًا.")

add_heading(doc, "14. نقاط الأمان والخصوصية", 1)
for text in [
    "صور الوجوه بيانات حساسة ويجب تحديد من يمكنه الوصول إليها ومدة الاحتفاظ بها.",
    "لوحة الإدارة حاليًا متاحة لمن يصل إلى الشبكة والمنفذ؛ ينبغي إضافة تسجيل دخول قبل الاستخدام الحقيقي.",
    "لا تُكتب كلمة مرور الجهاز في هذا التقرير أو داخل كود المشروع.",
    "ينبغي تغيير كلمة المرور الحالية إن كانت سهلة، وتقييد SSH عبر VPN أو شبكة موثوقة.",
    "يفضل نسخ attendance.db وdataset والنموذج احتياطيًا بصورة دورية ومشفرة.",
]:
    add_bullet(doc, text)

add_heading(doc, "15. المشكلات المفتوحة والتوصيات", 1)
add_table(doc, ["الأولوية", "الموضوع", "الإجراء المقترح"], [
    ("عالية", "الكاميرا الثانية غير مكتشفة", "فحص كابل CSI واتجاهه ومنفذ الكاميرا والطاقة، ثم إعادة فحص rpicam-hello --list-cameras."),
    ("عالية", "أسماء person1 إلى person4 مؤقتة", "استبدالها بالأسماء الحقيقية وإعادة التدريب أو إضافة بيانات وصفية."),
    ("عالية", "حماية لوحة الإدارة", "إضافة حساب مدير وجلسات آمنة وHTTPS عند التشغيل خارج شبكة معزولة."),
    ("متوسطة", "عتبة التعرف", "جمع اختبارات حقيقية وحساب false accept/false reject ثم ضبط العتبة."),
    ("متوسطة", "توقيت الجهاز", "تأكيد المنطقة الزمنية المطلوبة وضبطها لتجنب محاضرات بأوقات غير صحيحة."),
    ("متوسطة", "مراقبة الأداء", "قياس CPU والحرارة تحت تشغيل كاميرتين؛ العملية الحالية استخدمت نحو 762MB RAM."),
    ("منخفضة", "تقارير وتصدير", "إضافة تصدير CSV/PDF وسجل تدقيق للعمليات الإدارية."),
], [1200, 3000, 5160])

add_heading(doc, "16. اختبار القبول المقترح", 1)
for text in [
    "توصيل الكاميرتين والتأكد من ظهور Camera 0 وCamera 1 بحالة running.",
    "إنشاء محاضرة تجريبية مدتها 10 دقائق من لوحة الإدارة.",
    "تمرير طالب مسجل أمام كاميرا الدخول والتأكد من ظهور حدث entry مرة واحدة.",
    "تمرير الطالب أمام كاميرا الخروج والتأكد من ظهور حدث exit مرة واحدة.",
    "إنهاء المحاضرة والتحقق من ظهور نتيجة completed عند تحقق نسبة الزمن.",
    "اختبار شخص غير مسجل والتأكد من عدم إنشاء حدث باسم طالب آخر.",
    "إعادة تشغيل Raspberry Pi والتأكد من عودة لوحة التحكم وخدمة الكاميرات تلقائيًا.",
    "اختبار الوصول من LAN ومن WireGuard VPN.",
]:
    add_bullet(doc, text)

add_heading(doc, "خلاصة", 1)
add_p(doc, "أصبح الجهاز يملك نواة نظام حضور متكاملة مبنية على DeepFace: كشف ومحاذاة YuNet، تضمينات SFace، مقارنة Cosine، 85 مرجعًا، عمال كاميرات متزامنون، تسجيل من الواجهة، SQLite، محاضرات ونتائج، API ولوحة إدارة وبث مباشر. أهم خطوة تالية هي توصيل كاميرا الخروج، تسمية الطلاب الحقيقيين، حماية لوحة الإدارة، ثم اختبار الدقة ميدانيًا.")

# Keep headings with next and set table header repeat.
for table in doc.tables:
    first_tr_pr = table.rows[0]._tr.get_or_add_trPr()
    repeat = OxmlElement("w:tblHeader")
    repeat.set(qn("w:val"), "true")
    first_tr_pr.append(repeat)

doc.core_properties.title = "تقرير نظام الحضور بالتعرف على الوجه"
doc.core_properties.subject = "التوثيق التقني لمشروع Raspberry Pi 5 للحضور"
doc.core_properties.author = "Codex"
doc.save(OUT)
print("Arabic project report saved")
