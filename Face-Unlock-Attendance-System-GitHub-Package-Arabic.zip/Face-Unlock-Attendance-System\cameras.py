import hashlib
import os
import threading
import time

import cv2
import numpy as np
from deepface import DeepFace
from picamera2 import Picamera2


class DeepFaceRecognizer:
    def __init__(self, embeddings_path, model_name="SFace", detector_backend="yunet",
                 distance_threshold=0.593, minimum_face_confidence=0.80):
        self.embeddings_path = embeddings_path
        self.model_name = model_name
        self.detector_backend = detector_backend
        self.distance_threshold = float(distance_threshold)
        self.minimum_face_confidence = float(minimum_face_confidence)
        self.lock = threading.RLock()
        # DeepFace caches one OpenCV DNN model globally. OpenCV DNN forward()
        # is not thread-safe, so two camera workers must not enter it together.
        self.inference_lock = threading.Lock()
        self.embeddings = np.empty((0, 128), dtype=np.float32)
        self.embedding_names = np.empty((0,), dtype=str)
        self.names = []
        self.reload()
        # Build both DeepFace models once at startup, before camera threads race.
        DeepFace.build_model(model_name=self.model_name, task="facial_recognition")
        DeepFace.build_model(model_name=self.detector_backend, task="face_detector")

    def reload(self):
        if not os.path.isfile(self.embeddings_path):
            self.embeddings = np.empty((0, 128), dtype=np.float32)
            self.embedding_names = np.empty((0,), dtype=str)
            self.names = []
            return
        data = np.load(self.embeddings_path, allow_pickle=False)
        embeddings = np.asarray(data["embeddings"], dtype=np.float32)
        names = np.asarray(data["names"], dtype=str)
        if len(embeddings):
            embeddings /= np.maximum(np.linalg.norm(embeddings, axis=1, keepdims=True), 1e-12)
        with self.lock:
            self.embeddings = embeddings
            self.embedding_names = names
            self.names = sorted(set(names.tolist()))

    def representations(self, image, enforce_detection=True):
        with self.inference_lock:
            return DeepFace.represent(
                img_path=image,
                model_name=self.model_name,
                detector_backend=self.detector_backend,
                enforce_detection=enforce_detection,
                align=True,
                normalization="base",
            )

    def recognize(self, frame):
        try:
            representations = self.representations(frame, enforce_detection=True)
        except ValueError:
            return None
        if not representations:
            return None
        face = max(
            representations,
            key=lambda item: item.get("facial_area", {}).get("w", 0)
            * item.get("facial_area", {}).get("h", 0),
        )
        detection_confidence = float(face.get("face_confidence") or 0.0)
        if detection_confidence < self.minimum_face_confidence:
            return None
        query = np.asarray(face["embedding"], dtype=np.float32)
        query /= max(float(np.linalg.norm(query)), 1e-12)
        with self.lock:
            if not len(self.embeddings):
                return None
            distances = 1.0 - self.embeddings @ query
            best_index = int(np.argmin(distances))
            distance = float(distances[best_index])
            name = str(self.embedding_names[best_index])
        if distance > self.distance_threshold:
            return None
        similarity = max(0.0, min(100.0, (1.0 - distance) * 100.0))
        return name, similarity, distance, detection_confidence


class CameraWorker(threading.Thread):
    def __init__(self, index, direction, recognizer, callback, status, config):
        super().__init__(daemon=True, name=f"camera-{index}-{direction}")
        self.index = index
        self.direction = direction
        self.recognizer = recognizer
        self.callback = callback
        self.status = status
        self.config = config
        self.stop_event = threading.Event()
        self.frame_lock = threading.Lock()
        self.latest_jpeg = None
        self.latest_match = None
        self.recognition_frame = None
        self.recognition_sequence = 0
        self.preview_interval = 1.0 / max(float(config.get("preview_fps", 5)), 1.0)
        self.last_preview_at = 0.0
        self.last_frame_monotonic = 0.0
        self.last_recognition_monotonic = 0.0
        self.viewers = 0

    def add_viewer(self):
        with self.frame_lock:
            self.viewers += 1

    def remove_viewer(self):
        with self.frame_lock:
            self.viewers = max(0, self.viewers - 1)

    def get_jpeg(self):
        with self.frame_lock:
            return self.latest_jpeg

    def health(self):
        state = self.status.get(
            self.index, {"direction": self.direction, "state": "starting"}
        ).copy()
        now = time.monotonic()
        if state.get("state") == "running":
            frame_age = now - self.last_frame_monotonic if self.last_frame_monotonic else None
            recognition_age = (
                now - self.last_recognition_monotonic
                if self.last_recognition_monotonic else None
            )
            if frame_age is None or frame_age > 3:
                state["state"] = "stale"
            elif recognition_age is None or recognition_age > 30:
                state["state"] = "recognition_stale"
            state["frame_age_seconds"] = round(frame_age, 1) if frame_age is not None else None
            state["recognition_age_seconds"] = (
                round(recognition_age, 1) if recognition_age is not None else None
            )
        return state

    def publish_frame(self, frame, match):
        now = time.monotonic()
        with self.frame_lock:
            if now - self.last_preview_at < self.preview_interval:
                return
            self.last_preview_at = now
        preview = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
        cv2.putText(preview, f"Camera {self.index} - {self.direction.upper()}",
                    (14, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                    (255, 255, 255), 2, cv2.LINE_AA)
        if match:
            cv2.putText(preview, f"{match[0]}  similarity {match[1]:.1f}%",
                        (14, 62), cv2.FONT_HERSHEY_SIMPLEX, 0.65,
                        (0, 255, 0), 2, cv2.LINE_AA)
        ok, encoded = cv2.imencode(".jpg", preview, [cv2.IMWRITE_JPEG_QUALITY, 78])
        if ok:
            with self.frame_lock:
                self.latest_jpeg = encoded.tobytes()

    def recognition_loop(self):
        last_sequence = -1
        last_name = None
        streak = 0
        while not self.stop_event.is_set():
            with self.frame_lock:
                sequence = self.recognition_sequence
                frame = self.recognition_frame
            if frame is None or sequence == last_sequence:
                self.stop_event.wait(0.02)
                continue

            last_sequence = sequence
            match = self.recognizer.recognize(frame)
            with self.frame_lock:
                self.latest_match = match
                self.last_recognition_monotonic = time.monotonic()

            name = match[0] if match else None
            streak = streak + 1 if name and name == last_name else (1 if name else 0)
            last_name = name
            if match and streak >= self.config["recognition_streak"]:
                evidence_hash = hashlib.sha256(frame.tobytes()).hexdigest()
                self.callback(
                    name, self.direction, match[1], self.index, evidence_hash
                )
                streak = 0

            # Give the other camera's DeepFace worker a chance to acquire the
            # shared inference lock before this worker processes another frame.
            self.stop_event.wait(0.05)

    def run(self):
        camera = None
        recognition_thread = None
        try:
            camera = Picamera2(self.index)
            cfg = camera.create_preview_configuration(main={
                "size": (self.config["camera_width"], self.config["camera_height"]),
                "format": "XRGB8888",
            })
            camera.configure(cfg)
            camera.start()
            time.sleep(1)
            self.status[self.index] = {"direction": self.direction, "state": "running"}
            recognition_thread = threading.Thread(
                target=self.recognition_loop,
                daemon=True,
                name=f"recognition-{self.index}-{self.direction}",
            )
            recognition_thread.start()
            while not self.stop_event.is_set():
                frame = camera.capture_array()
                with self.frame_lock:
                    self.last_frame_monotonic = time.monotonic()
                    self.recognition_frame = frame.copy()
                    self.recognition_sequence += 1
                    match = self.latest_match
                self.publish_frame(frame, match)
        except Exception as exc:
            self.status[self.index] = {
                "direction": self.direction, "state": "error", "error": str(exc)
            }
        finally:
            self.stop_event.set()
            if recognition_thread:
                recognition_thread.join(timeout=2)
            if camera:
                camera.stop()

    def stop(self):
        self.stop_event.set()
