# دليل رفع واستضافة مشروع Face Unlock Attendance System

هذا الدليل مكتوب لشخص لا يملك خبرة سابقة بمنصة GitHub. اتبع الخطوات بالترتيب
ولا ترفع أي صور طلاب أو قاعدة بيانات حضور أو كلمات مرور. أسماء الملفات
والأوامر مكتوبة كما يجب إدخالها حرفياً، أما جميع خطوات الشرح فهي باللغة
العربية.

## ما الذي تعنيه الاستضافة هنا؟

هناك شيئان مختلفان:

1. **استضافة الشيفرة المصدرية على GitHub:** حفظ ملفات المشروع ومشاركتها وتتبع
   تعديلاتها. تكتمل هذه الخطوة بعد رفع محتويات هذه الحزمة إلى مستودع GitHub.
2. **تشغيل النظام بوصفه خدمة ويب:** يجب أن يعمل تطبيق Flask وخوارزمية DeepFace
   على جهاز Raspberry Pi المتصل بالكاميرتين. لا يستطيع GitHub Pages تشغيل
   بايثون أو Flask أو بث كاميرات Raspberry Pi؛ فهو مخصص للمواقع الثابتة فقط.

إذن رابط GitHub يعرض الكود، بينما رابط لوحة الحضور يأتي من Raspberry Pi، مثل:

```text
http://RASPBERRY_PI_IP:5000
```

## القسم الأول: رفع المشروع إلى GitHub بالطريقة الأسهل

### 1. فك ضغط الحزمة

1. انسخ الملف المضغوط إلى الحاسوب.
2. اضغط عليه بزر الفأرة الأيمن.
3. اختر **استخراج الكل** ثم **استخراج**.
4. افتح المجلد الناتج وتأكد من وجود `README.md` و`app.py` و`templates`.

لا ترفع الملف المضغوط نفسه بوصفه المشروع. ارفع الملفات الموجودة داخله.

### 2. إنشاء المستودع

1. سجل الدخول إلى [GitHub](https://github.com/).
2. افتح صفحة [إنشاء مستودع جديد](https://github.com/new).
3. اكتب الاسم التالي في خانة **اسم المستودع**:

   ```text
   Face-Unlock-Attendance-System
   ```

4. اكتب وصفاً مثل:

   ```text
   نظام حضور على Raspberry Pi 5 يستخدم DeepFace وبث كاميرتين.
   ```

5. اختر **خاص** في البداية. يمكن تحويله إلى **عام** لاحقاً بعد مراجعة الملفات
   والتأكد من عدم وجود بيانات طلاب.
6. لا تفعل خيارات إضافة ملف القراءة `README` أو ملف التجاهل `.gitignore` أو
   الرخصة؛ فهذه الحزمة تحتوي بالفعل على الملفات المطلوبة.
7. اضغط **إنشاء المستودع**.

### 3. رفع الملفات

1. في صفحة المستودع الجديد اضغط **رفع ملف موجود**. إذا لم يظهر الرابط، اختر
   **إضافة ملف** ثم **رفع الملفات**.
2. افتح المجلد الذي فككت ضغطه على نظام ويندوز.
3. حدد **كل المحتويات داخل المجلد**، وليس المجلد الخارجي نفسه.
4. اسحب الملفات والمجلدات إلى صفحة GitHub.
5. انتظر حتى ينتهي رفع جميع الملفات.
6. اكتب في خانة **رسالة التعديل**:

   ```text
   الرفع الأول الآمن للمشروع
   ```

7. اختر **حفظ التعديل مباشرة في الفرع الرئيسي** ثم اضغط **حفظ التغييرات**.

### 4. التحقق بعد الرفع

يجب أن تظهر على GitHub الملفات والمجلدات التالية:

```text
.env.example
.gitignore
README.md
GITHUB_UPLOAD_AND_HOSTING_GUIDE.md
app.py
attendance.py
backup_attendance.py
build_arabic_report.py
cameras.py
config.json
enrollment.py
requirements-deepface.txt
requirements-documentation.txt
security.py
static/
templates/
test_attendance_security.py
test_web_security.py
face-attendance.service
face-attendance-backup.service
face-attendance-backup.timer
```

يجب **ألا** تظهر أي من العناصر التالية:

```text
attendance.db
attendance.db-wal
attendance.db-shm
deepface_embeddings.npz
dataset/
students/
uploads/
backups/
.env
صور الطلاب
كلمات المرور
```

إذا ظهر شيء من هذه القائمة، اجعل المستودع خاصاً واحذف الملف فوراً. لا يكفي
حذف كلمة المرور من آخر نسخة فقط إذا كانت قد دخلت سجل تعديلات Git.

## القسم الثاني: مشاركة المستودع

إذا كان المستودع **عاماً**، انسخ رابطه من شريط العنوان وأرسله لمن تريد.

إذا كان **خاصاً**:

1. افتح المستودع.
2. افتح **الإعدادات**.
3. افتح **المتعاونون** أو **المتعاونون والفرق**.
4. اضغط **إضافة أشخاص**.
5. اكتب اسم حساب الشخص وأرسل الدعوة.

لا تشارك كلمة مرور حساب GitHub مع أي شخص.

## القسم الثالث: تحديث المشروع لاحقاً

للمبتدئ يمكن استخدام نفس طريقة المتصفح:

1. افتح المستودع.
2. اختر **إضافة ملف** ثم **رفع الملفات**.
3. ارفع الملفات المعدلة.
4. اكتب رسالة واضحة، مثل `تحديث معالجة الكاميرات`.
5. اضغط **حفظ التغييرات**.

عند زيادة عدد التعديلات، يفضل تثبيت
[برنامج GitHub للحاسوب](https://desktop.github.com/) واستعماله لنسخ المستودع
وحفظ التعديلات وإرسالها بدلاً من رفع الملفات يدوياً.

## القسم الرابع: تشغيل النظام على Raspberry Pi

هذه الخطوات تنفذ على Raspberry Pi، وليست مطلوبة لمجرد عرض الكود على GitHub.

### المتطلبات

- Raspberry Pi 5.
- نظام Raspberry Pi OS مع بايثون 3.
- كاميرا أو كاميرتان متصلتان ومفعلتان.
- اتصال شبكة آمن.
- برنامج Git مثبت على الجهاز.

### 1. تنزيل المستودع

استبدل `GITHUB_USERNAME` باسم صاحب المستودع:

```bash
cd /home/senior
git clone https://github.com/GITHUB_USERNAME/Face-Unlock-Attendance-System.git attendance-system
cd attendance-system
```

إذا كان المستودع خاصاً، يجب تسجيل الدخول بأداة أوامر GitHub أو استخدام وسيلة
مصادقة آمنة. لا تضع كلمة المرور داخل رابط المستودع.

### 2. تثبيت مكونات النظام

```bash
sudo apt update
sudo apt install -y git python3-venv python3-picamera2 python3-opencv
python3 -m venv --system-site-packages .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements-deepface.txt
```

قد يستغرق تثبيت TensorFlow وDeepFace وقتاً طويلاً، كما يجب أن تكون إصداراتهما
متوافقة مع بايثون ومعمارية ARM المستخدمين على الجهاز.

### 3. مراجعة المسارات

افتح `config.json` وتأكد من صحة:

```json
"dataset_path": "/home/senior/face_project/dataset",
"embeddings_path": "/home/senior/attendance-system/deepface_embeddings.npz"
```

إذا كان اسم مستخدم Raspberry Pi مختلفاً عن `senior`، عدل هذه المسارات وعدل
حقول `User` و`WorkingDirectory` و`ExecStart` داخل ملفات خدمة النظام.

### 4. إنشاء أسرار الإدارة

أنشئ مفتاحين مختلفين:

```bash
python -c "import secrets; print(secrets.token_hex(32))"
python -c "import secrets; print(secrets.token_hex(32))"
```

ثم أنشئ بصمة مشفرة لكلمة مرور الإدارة:

```bash
python -c "from werkzeug.security import generate_password_hash; print(generate_password_hash(input('Admin password: ')))"
```

أنشئ الملف المحمي:

```bash
sudo nano /etc/face-attendance.env
```

ضع فيه القيم التالية بعد استبدال النصوص التوضيحية بالقيم التي أنشأتها:

```text
ATTENDANCE_SECRET_KEY=FIRST_RANDOM_VALUE
ATTENDANCE_AUDIT_KEY=SECOND_RANDOM_VALUE
ATTENDANCE_ADMIN_USERNAME=admin
ATTENDANCE_ADMIN_PASSWORD_HASH=GENERATED_PASSWORD_HASH
ATTENDANCE_COOKIE_SECURE=0
ATTENDANCE_START_CAMERAS=1
```

ثم احفظه واحمه:

```bash
sudo chown root:root /etc/face-attendance.env
sudo chmod 600 /etc/face-attendance.env
```

لا تضع ملف `/etc/face-attendance.env` أو قيمه داخل GitHub.

### 5. تثبيت الخدمة

```bash
sudo cp face-attendance.service /etc/systemd/system/
sudo cp face-attendance-backup.service /etc/systemd/system/
sudo cp face-attendance-backup.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now face-attendance.service
sudo systemctl enable --now face-attendance-backup.timer
```

### 6. فحص الخدمة

```bash
sudo systemctl status face-attendance.service
sudo journalctl -u face-attendance.service -f
```

اعرف عنوان الجهاز:

```bash
hostname -I
```

ثم افتح من جهاز على الشبكة نفسها:

```text
http://RASPBERRY_PI_IP:5000
```

## القسم الخامس: الوصول من خارج شبكة الجامعة

لا تفتح المنفذ `5000` مباشرة على الإنترنت، لأن النظام يعالج بيانات حضور وصوراً
وبيانات بيومترية. الخيار المنطقي هو إبقاء التطبيق على Raspberry Pi والوصول
إليه عبر شبكة افتراضية خاصة. إذا تقرر نشره للعامة، يجب وضع خادم وسيط عكسي
يدعم اتصال HTTPS المشفر أمام Gunicorn، وتقييد الوصول، وتفعيل:

```text
ATTENDANCE_COOKIE_SECURE=1
```

GitHub Pages لا يشغل هذا النظام لأنه لا يدعم بايثون أو Flask أو الاتصال
بكاميرات Raspberry Pi. يمكن استعمال GitHub Pages لاحقاً لصفحة تعريف ثابتة
عن المشروع فقط، وليست لوحة الحضور الحقيقية.

## القسم السادس: قائمة أمان قبل جعل المستودع عاماً

- لا توجد صور وجوه أو مجلد بيانات التدريب.
- لا توجد قاعدة `attendance.db` أو نسخ احتياطية.
- لا يوجد ملف `.env`.
- لا توجد كلمات مرور أو مفاتيح أو رموز وصول.
- لا توجد تمثيلات رقمية بيومترية للوجوه.
- عناوين الشبكة الداخلية ليست مطلوبة في الوثائق العامة.
- تم تغيير أي كلمة مرور سبق إرسالها في محادثة أو رسالة.
- تم الحصول على موافقة الجامعة قبل نشر الشعار أو المشروع باسمها.

## روابط المساعدة الرسمية

- [رفع مشروع إلى GitHub](https://docs.github.com/en/get-started/start-your-journey/uploading-a-project-to-github)
- [إضافة شيفرة موجودة محلياً إلى GitHub](https://docs.github.com/en/migrations/importing-source-code/using-the-command-line-to-import-source-code/adding-locally-hosted-code-to-github)
- [إنشاء موقع باستخدام GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site)
