import os
import unittest
from unittest.mock import patch

from flask import Flask, jsonify, session
from werkzeug.security import generate_password_hash

from security import configure_security, csrf_token, safe_next_url


class WebSecurityTests(unittest.TestCase):
    def setUp(self):
        environment = {
            "ATTENDANCE_SECRET_KEY": "test-secret-key",
            "ATTENDANCE_ADMIN_USERNAME": "admin",
            "ATTENDANCE_ADMIN_PASSWORD_HASH": generate_password_hash("test-password"),
        }
        self.environment = patch.dict(os.environ, environment)
        self.environment.start()
        self.app = Flask(__name__)
        configure_security(self.app)

        @self.app.route("/login", methods=["GET", "POST"])
        def login():
            return "login"

        @self.app.get("/")
        def admin_dashboard():
            return "dashboard"

        @self.app.get("/healthz")
        def healthz():
            return jsonify({"status": "ok"})

        @self.app.post("/api/write")
        def write():
            return jsonify({"saved": True})

        self.client = self.app.test_client()

    def tearDown(self):
        self.environment.stop()

    def test_api_requires_login(self):
        self.assertEqual(self.client.post("/api/write").status_code, 401)

    def test_authenticated_writes_require_csrf(self):
        with self.client.session_transaction() as stored:
            stored["authenticated"] = True
            stored["csrf_token"] = "known-token"
        self.assertEqual(self.client.post("/api/write").status_code, 403)
        response = self.client.post(
            "/api/write", headers={"X-CSRF-Token": "known-token"}
        )
        self.assertEqual(response.status_code, 200)

    def test_external_next_url_is_rejected(self):
        with self.app.test_request_context("/login"):
            self.assertEqual(safe_next_url("https://evil.example/"), "/")
            self.assertEqual(safe_next_url("/api/status"), "/api/status")


if __name__ == "__main__":
    unittest.main()
