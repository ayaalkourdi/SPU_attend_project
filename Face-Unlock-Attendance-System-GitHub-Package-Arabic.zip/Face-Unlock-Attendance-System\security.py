import hmac
import os
import secrets
import threading
import time
from collections import defaultdict, deque
from urllib.parse import urlsplit

from flask import jsonify, redirect, request, session, url_for
from werkzeug.security import check_password_hash


SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}


class LoginLimiter:
    def __init__(self, attempts=5, window_seconds=300):
        self.attempts = attempts
        self.window_seconds = window_seconds
        self.lock = threading.Lock()
        self.failures = defaultdict(deque)

    def allowed(self, address):
        now = time.monotonic()
        with self.lock:
            queue = self.failures[address]
            while queue and now - queue[0] > self.window_seconds:
                queue.popleft()
            return len(queue) < self.attempts

    def failed(self, address):
        with self.lock:
            self.failures[address].append(time.monotonic())

    def succeeded(self, address):
        with self.lock:
            self.failures.pop(address, None)


def required_environment(name):
    value = os.environ.get(name, "").strip()
    if not value:
        raise RuntimeError(f"Required environment variable {name} is not configured")
    return value


def csrf_token():
    token = session.get("csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["csrf_token"] = token
    return token


def valid_csrf():
    expected = session.get("csrf_token", "")
    supplied = request.headers.get("X-CSRF-Token") or request.form.get("csrf_token", "")
    return bool(expected and supplied and hmac.compare_digest(expected, supplied))


def safe_next_url(value):
    if not value:
        return url_for("admin_dashboard")
    parsed = urlsplit(value)
    if parsed.scheme or parsed.netloc or not value.startswith("/"):
        return url_for("admin_dashboard")
    return value


def configure_security(app):
    app.config.update(
        SECRET_KEY=required_environment("ATTENDANCE_SECRET_KEY"),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Strict",
        SESSION_COOKIE_SECURE=os.environ.get("ATTENDANCE_COOKIE_SECURE", "0") == "1",
        PERMANENT_SESSION_LIFETIME=1800,
    )
    app.config["ADMIN_USERNAME"] = os.environ.get("ATTENDANCE_ADMIN_USERNAME", "admin")
    app.config["ADMIN_PASSWORD_HASH"] = required_environment("ATTENDANCE_ADMIN_PASSWORD_HASH")
    limiter = LoginLimiter()

    @app.before_request
    def require_authentication():
        if request.endpoint in {"login", "static", "healthz"}:
            return None
        if not session.get("authenticated"):
            if request.path.startswith("/api/"):
                return jsonify({"error": "Authentication required"}), 401
            return redirect(url_for("login", next=request.full_path))
        session.permanent = True
        if request.method not in SAFE_METHODS and not valid_csrf():
            if request.path.startswith("/api/"):
                return jsonify({"error": "Invalid CSRF token"}), 403
            return "Invalid CSRF token", 403
        return None

    @app.after_request
    def security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; img-src 'self' blob:; "
            "style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; "
            "object-src 'none'; base-uri 'none'; frame-ancestors 'none'"
        )
        if request.path.startswith("/api/") or request.endpoint in {"login", "admin_dashboard"}:
            response.headers["Cache-Control"] = "no-store"
        return response

    def authenticate(username, password):
        address = request.remote_addr or "unknown"
        if not limiter.allowed(address):
            return False, "Too many failed attempts. Try again in five minutes."
        valid = (
            hmac.compare_digest(username, app.config["ADMIN_USERNAME"])
            and check_password_hash(app.config["ADMIN_PASSWORD_HASH"], password)
        )
        if valid:
            limiter.succeeded(address)
            return True, None
        limiter.failed(address)
        return False, "Invalid username or password."

    return authenticate
