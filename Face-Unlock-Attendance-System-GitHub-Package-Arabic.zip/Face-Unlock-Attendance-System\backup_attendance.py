import os
import sqlite3
import time
from datetime import datetime


BASE = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.path.join(BASE, "attendance.db")
BACKUP_DIRECTORY = os.path.join(BASE, "backups")
RETENTION_DAYS = 30


def main():
    os.makedirs(BACKUP_DIRECTORY, mode=0o700, exist_ok=True)
    timestamp = datetime.now().astimezone().strftime("%Y%m%dT%H%M%S%z")
    temporary = os.path.join(BACKUP_DIRECTORY, f".attendance-{timestamp}.db")
    destination = os.path.join(BACKUP_DIRECTORY, f"attendance-{timestamp}.db")
    with sqlite3.connect(DATABASE) as source, sqlite3.connect(temporary) as target:
        source.backup(target)
        integrity = target.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise RuntimeError(f"Backup integrity check failed: {integrity}")
    os.chmod(temporary, 0o600)
    os.replace(temporary, destination)

    cutoff = time.time() - RETENTION_DAYS * 86400
    for filename in os.listdir(BACKUP_DIRECTORY):
        path = os.path.join(BACKUP_DIRECTORY, filename)
        if (
            filename.startswith("attendance-")
            and filename.endswith(".db")
            and os.path.isfile(path)
            and os.path.getmtime(path) < cutoff
        ):
            os.unlink(path)
    print(destination)


if __name__ == "__main__":
    main()
