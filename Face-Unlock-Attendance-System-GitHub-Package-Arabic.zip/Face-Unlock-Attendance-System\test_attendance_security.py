import os
import sqlite3
import tempfile
import unittest
from contextlib import closing
from datetime import datetime, timedelta

from attendance import AttendanceStore


class AttendanceSecurityTests(unittest.TestCase):
    def setUp(self):
        handle, self.path = tempfile.mkstemp(suffix=".db")
        os.close(handle)
        self.store = AttendanceStore(self.path, minimum_presence_ratio=0.9, audit_key="test-key")

    def tearDown(self):
        for suffix in ("", "-shm", "-wal"):
            try:
                os.unlink(self.path + suffix)
            except FileNotFoundError:
                pass

    def test_registration_is_unique_and_audited(self):
        self.store.register_student("Student One", "SPU-001")
        with self.assertRaises(ValueError):
            self.store.register_student("Student Two", "SPU-001")
        self.assertEqual(self.store.verify_audit(), {"valid": True, "entries": 1})

    def test_presence_uses_closed_sessions_not_first_and_last_event(self):
        student_id = self.store.register_student("Student One", "SPU-001")
        start = datetime.now().astimezone() - timedelta(hours=2)
        end = start + timedelta(hours=1)
        lecture_id = self.store.add_lecture(
            "Past lecture", start.isoformat(), end.isoformat()
        )
        with self.store.connect() as db:
            for direction, minutes in (
                ("entry", 0), ("exit", 30), ("entry", 40), ("exit", 60)
            ):
                db.execute(
                    """INSERT INTO events(
                         lecture_id,student_id,direction,occurred_at,source,created_at
                       ) VALUES(?,?,?,?,?,?)""",
                    (
                        lecture_id,
                        student_id,
                        direction,
                        (start + timedelta(minutes=minutes)).isoformat(),
                        "test",
                        datetime.now().astimezone().isoformat(),
                    ),
                )
        result = self.store.finalize(lecture_id)[0]
        self.assertEqual(result["result"], "insufficient_duration")
        self.assertEqual(result["session_count"], 2)
        self.assertAlmostEqual(result["presence_ratio"], 50 / 60, places=3)
        self.assertAlmostEqual(result["gap_seconds"], 600, delta=1)

    def test_audit_tampering_is_detected(self):
        self.store.register_student("Student One", "SPU-001")
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("UPDATE audit_log SET payload_json='{}' WHERE sequence=1")
            db.commit()
        result = self.store.verify_audit()
        self.assertFalse(result["valid"])
        self.assertEqual(result["failed_sequence"], 1)

    def test_legacy_student_can_receive_a_unique_university_id(self):
        student_id = self.store.ensure_student("Legacy Student")
        result = self.store.set_university_id(student_id, "spu-legacy-1")
        self.assertEqual(result["university_id"], "SPU-LEGACY-1")
        self.assertTrue(self.store.verify_audit()["valid"])


if __name__ == "__main__":
    unittest.main()
