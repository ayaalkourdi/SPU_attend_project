import atexit
import json
import os
import threading
import time

from flask import (
    Flask, Response, jsonify, redirect, render_template, request, session,
    url_for,
)

from attendance import AttendanceStore
from cameras import CameraWorker, DeepFaceRecognizer
from enrollment import EnrollmentError, EnrollmentManager
from security import (
    configure_security, csrf_token, required_environment, safe_next_url,
)

BASE = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(BASE, "config.json"), encoding="utf-8") as handle:
    CONFIG = json.load(handle)
if not os.path.isabs(CONFIG["database"]):
    CONFIG["database"] = os.path.join(BASE, CONFIG["database"])

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = int(CONFIG["max_upload_megabytes"]) * 1024 * 1024
authenticate_admin = configure_security(app)
store = AttendanceStore(
    CONFIG["database"],
    CONFIG["minimum_presence_ratio"],
    required_environment("ATTENDANCE_AUDIT_KEY"),
)
recognizer = DeepFaceRecognizer(
    CONFIG["embeddings_path"],
    CONFIG["deepface_model"],
    CONFIG["deepface_detector"],
    CONFIG["distance_threshold"],
    CONFIG["minimum_face_confidence"],
)
store.sync_students(recognizer.names)
enrollment = EnrollmentManager(
    CONFIG, recognizer, store.validate_new_student, store.register_student
)
camera_status = {}
workers = []
last_events = {}
last_events_lock = threading.Lock()


def recognized(name, direction, confidence, camera_index, evidence_hash):
    key = (name, direction)
    current = time.monotonic()
    with last_events_lock:
        if current - last_events.get(key, 0) < CONFIG["event_cooldown_seconds"]:
            return
    result = store.record_camera_event(
        name,
        direction,
        confidence,
        camera_index,
        f"{CONFIG['deepface_model']}:{CONFIG['deepface_detector']}",
        evidence_hash,
    )
    with last_events_lock:
        last_events[key] = current
    print(f"{direction.upper()}: {name} confidence={confidence:.1f} lecture={result['lecture_id']}", flush=True)


def start_cameras():
    try:
        count = len(__import__("picamera2").Picamera2.global_camera_info())
    except Exception:
        count = 0
    for item in CONFIG["cameras"]:
        idx = int(item["index"])
        if idx >= count:
            camera_status[idx] = {"direction": item["direction"], "state": "not_detected"}
            continue
        worker = CameraWorker(idx, item["direction"], recognizer, recognized, camera_status, CONFIG)
        workers.append(worker)
        worker.start()


@atexit.register
def stop_cameras():
    for worker in workers:
        worker.stop()


@app.get("/legacy")
def dashboard():
    return redirect(url_for("admin_dashboard"))
    return """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Face Attendance</title><style>
body{font-family:system-ui;background:#0f172a;color:#e2e8f0;margin:0;padding:24px}
.wrap{max-width:1050px;margin:auto}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}
.card{background:#1e293b;padding:18px;border-radius:14px}h1{margin-top:0}table{width:100%;border-collapse:collapse}
td,th{padding:10px;text-align:left;border-bottom:1px solid #334155}.entry{color:#4ade80}.exit{color:#fbbf24}
button{background:#2563eb;color:white;border:0;padding:10px 14px;border-radius:8px;cursor:pointer}
button:disabled{opacity:.5}input{background:#0f172a;color:#e2e8f0;border:1px solid #475569;border-radius:7px;padding:9px;margin:6px 18px 12px 0}.muted{color:#94a3b8}
</style></head><body><div class="wrap"><h1>Face Unlock Attendance</h1>
<div class="cards"><div class="card"><h3>Active lecture</h3><div id="lecture">Loading…</div></div>
<div class="card"><h3>Cameras</h3><div id="cams">Loading…</div></div></div>
<div class="card" style="margin-top:14px"><h3>Add a student</h3>
<form id="enroll"><label>Student name<br><input id="studentName" name="name" required maxlength="80"></label>
<label>Photos (20–30)<br><input id="studentPhotos" name="photos" type="file" accept="image/*" multiple required></label>
<button type="submit">Upload and train</button><div id="enrollStatus" class="muted"></div></form></div>
<div class="card" style="margin-top:14px"><h3>Recent events</h3><table><thead><tr>
<th>Student</th><th>Direction</th><th>Time</th><th>Lecture</th><th>Confidence</th></tr></thead><tbody id="events"></tbody></table></div>
<script>async function refresh(){let s=await(await fetch('/api/status')).json();
lecture.innerHTML=s.active_lecture?`<b>${s.active_lecture.name}</b><br><span class=muted>${s.active_lecture.starts_at} — ${s.active_lecture.ends_at}</span>`:'No active lecture';
cams.innerHTML=Object.entries(s.cameras).map(([i,c])=>`Camera ${i} (${c.direction}): <b>${c.state}</b>`).join('<br>');
let es=await(await fetch('/api/events')).json();events.innerHTML=es.map(e=>`<tr><td>${e.student_name}</td><td class=${e.direction}>${e.direction}</td><td>${e.occurred_at}</td><td>${e.lecture_name||'Outside lecture'}</td><td>${e.confidence==null?'—':e.confidence.toFixed(1)}</td></tr>`).join('')}
refresh();setInterval(refresh,3000);
enroll.onsubmit=async(e)=>{e.preventDefault();let files=studentPhotos.files;
if(files.length<20||files.length>30){enrollStatus.textContent='Please select between 20 and 30 photos.';return}
let b=e.submitter;b.disabled=true;enrollStatus.textContent='Uploading, validating faces, and training…';
try{let r=await fetch('/api/students',{method:'POST',body:new FormData(enroll)});let d=await r.json();
if(!r.ok)throw new Error(d.error||'Enrollment failed');
enrollStatus.textContent=`Added ${d.name}: ${d.accepted} photos accepted${d.rejected.length?' ('+d.rejected.length+' rejected)':''}. Recognition model reloaded.`;
    enroll.reset()}catch(x){enrollStatus.textContent=x.message}finally{b.disabled=false}}</script></div></body></html>"""


@app.get("/")
def admin_dashboard():
    return render_template("dashboard.html", csrf_token=csrf_token())


@app.route("/login", methods=["GET", "POST"])
def login():
    next_url = safe_next_url(request.values.get("next", ""))
    error = None
    if request.method == "POST":
        from security import valid_csrf
        if not valid_csrf():
            error = "The login form expired. Please try again."
        else:
            valid, error = authenticate_admin(
                request.form.get("username", ""),
                request.form.get("password", ""),
            )
            if valid:
                session.clear()
                session["authenticated"] = True
                session["username"] = app.config["ADMIN_USERNAME"]
                csrf_token()
                return redirect(next_url)
    return render_template(
        "login.html", error=error, next_url=next_url, csrf_token=csrf_token()
    )


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.get("/healthz")
def healthz():
    return jsonify({"status": "ok"})


def camera_worker(index):
    return next((worker for worker in workers if worker.index == index), None)


@app.get("/api/cameras/<int:index>/snapshot")
def camera_snapshot(index):
    worker = camera_worker(index)
    if worker is None:
        return jsonify({"error": "Camera is not detected"}), 404
    jpeg = worker.get_jpeg()
    if jpeg is None:
        return jsonify({"error": "Camera frame is not ready"}), 503
    return Response(
        jpeg,
        mimetype="image/jpeg",
        headers={"Cache-Control": "no-store, no-cache, must-revalidate"},
    )


@app.get("/api/status")
def status():
    statuses = dict(camera_status)
    for worker in workers:
        statuses[worker.index] = worker.health()
    return jsonify({
        "active_lecture": store.active_lecture(),
        "cameras": statuses,
        "summary": store.summary(),
        "audit": store.verify_audit(),
        "recognition": {
            "framework": "DeepFace",
            "model": CONFIG["deepface_model"],
            "detector": CONFIG["deepface_detector"],
            "metric": CONFIG["distance_metric"],
            "threshold": CONFIG["distance_threshold"],
            "reference_embeddings": len(recognizer.embeddings),
        },
    })


@app.get("/api/students")
def students():
    return jsonify(store.students())


@app.get("/api/results")
def all_results():
    return jsonify(store.all_results(min(int(request.args.get("limit", 500)), 1000)))


@app.get("/api/events")
def events():
    return jsonify(store.recent_events(min(int(request.args.get("limit", 100)), 500)))


@app.post("/api/students")
def add_student():
    try:
        result = enrollment.enroll(
            request.form.get("name", ""),
            request.form.get("university_id", ""),
            request.files.getlist("photos"),
        )
        return jsonify(result), 201
    except EnrollmentError as exc:
        return jsonify({"error": str(exc)}), 400
    except Exception:
        app.logger.exception("student enrollment failed")
        return jsonify({"error": "Training failed; the previous recognition model is still active"}), 500


@app.post("/api/students/<int:student_id>/university-id")
def set_student_university_id(student_id):
    try:
        data = request.get_json(force=True)
        return jsonify(store.set_university_id(student_id, data["university_id"]))
    except (KeyError, TypeError, ValueError) as exc:
        return jsonify({"error": str(exc)}), 400


@app.get("/api/lectures")
def lectures():
    return jsonify(store.lectures())


@app.post("/api/lectures")
def add_lecture():
    try:
        data = request.get_json(force=True)
        lecture_id = store.add_lecture(data["name"], data["starts_at"], data["ends_at"])
        return jsonify({"id": lecture_id}), 201
    except (KeyError, TypeError, ValueError) as exc:
        return jsonify({"error": str(exc)}), 400


@app.post("/api/lectures/<int:lecture_id>/finalize")
def finalize(lecture_id):
    try:
        return jsonify(store.finalize(lecture_id))
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400


@app.get("/api/lectures/<int:lecture_id>/results")
def results(lecture_id):
    return jsonify(store.results(lecture_id))


if os.environ.get("ATTENDANCE_START_CAMERAS", "1") == "1":
    start_cameras()


if __name__ == "__main__":
    app.run(host=CONFIG["host"], port=int(CONFIG["port"]), threaded=True, use_reloader=False)
