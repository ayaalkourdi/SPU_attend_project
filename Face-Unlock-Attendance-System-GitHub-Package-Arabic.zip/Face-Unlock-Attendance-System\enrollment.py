import hashlib
import json
import os
import re
import shutil
import tempfile
import threading
import uuid

import cv2
import numpy as np
from deepface import DeepFace


class EnrollmentError(ValueError):
    pass


class EnrollmentManager:
    def __init__(self, config, recognizer, student_validator, student_callback):
        self.config = config
        self.recognizer = recognizer
        self.student_validator = student_validator
        self.student_callback = student_callback
        self.lock = threading.Lock()

    @staticmethod
    def safe_folder(name):
        clean = " ".join(name.strip().split())
        if (
            not clean
            or len(clean) > 80
            or any(ord(character) < 32 for character in clean)
        ):
            raise EnrollmentError(
                "Student name is required and must be under 80 characters"
            )
        return clean

    def represent(self, image):
        try:
            faces = self.recognizer.representations(image, enforce_detection=True)
        except ValueError:
            return None
        if len(faces) != 1:
            return None
        face = faces[0]
        confidence = float(face.get("face_confidence") or 0.0)
        if confidence < self.recognizer.minimum_face_confidence:
            return None
        embedding = np.asarray(face["embedding"], dtype=np.float32)
        embedding /= max(float(np.linalg.norm(embedding)), 1e-12)
        return embedding

    def enroll(self, display_name, university_id, files):
        display_name = " ".join(display_name.strip().split())
        self.safe_folder(display_name)
        university_id = university_id.strip().upper()
        if not re.fullmatch(r"[A-Z0-9_-]{3,30}", university_id):
            raise EnrollmentError(
                "University ID must be 3–30 letters, numbers, underscores or hyphens"
            )
        try:
            self.student_validator(display_name, university_id)
        except ValueError as exc:
            raise EnrollmentError(str(exc)) from exc
        folder_name = university_id
        minimum = int(self.config["enrollment_min_photos"])
        maximum = int(self.config["enrollment_max_photos"])
        if not minimum <= len(files) <= maximum:
            raise EnrollmentError(f"Select between {minimum} and {maximum} photos")
        dataset = self.config["dataset_path"]
        os.makedirs(dataset, exist_ok=True)
        stage = os.path.join(dataset, f".upload-{uuid.uuid4().hex}")
        os.makedirs(stage)
        rejected = []
        candidate_embeddings = []
        seen_uploads = set()
        try:
            for index, upload in enumerate(files, 1):
                raw = upload.read()
                digest = hashlib.sha256(raw).digest()
                if not raw or digest in seen_uploads or len(raw) > 10 * 1024 * 1024:
                    rejected.append(upload.filename or f"photo {index}")
                    continue
                seen_uploads.add(digest)
                image = cv2.imdecode(
                    np.frombuffer(raw, np.uint8), cv2.IMREAD_COLOR
                ) if raw else None
                embedding = self.represent(image) if image is not None else None
                if (
                    image is None
                    or embedding is None
                    or min(image.shape[:2]) < 160
                    or max(image.shape[:2]) > 6000
                ):
                    rejected.append(upload.filename or f"photo {index}")
                    continue
                candidate_embeddings.append(embedding)
                cv2.imwrite(
                    os.path.join(stage, f"photo_{index:03d}.jpg"),
                    image, [cv2.IMWRITE_JPEG_QUALITY, 92],
                )
            accepted = len(files) - len(rejected)
            if accepted < minimum:
                raise EnrollmentError(
                    f"Only {accepted} usable photos were found; at least {minimum} "
                    "must contain exactly one clear face"
                )
            candidates = np.asarray(candidate_embeddings, dtype=np.float32)
            centroid = candidates.mean(axis=0)
            centroid /= max(float(np.linalg.norm(centroid)), 1e-12)
            intra_distances = 1.0 - candidates @ centroid
            consistent = int(np.count_nonzero(
                intra_distances <= float(self.config.get("enrollment_max_intra_distance", 0.35))
            ))
            if consistent < minimum:
                raise EnrollmentError(
                    "The uploaded photos do not consistently show the same person"
                )

            with self.recognizer.lock:
                existing = self.recognizer.embeddings.copy()
                existing_names = self.recognizer.embedding_names.copy()
            if len(existing):
                distances = 1.0 - candidates @ existing.T
                best_indexes = np.argmin(distances, axis=1)
                best_distances = distances[np.arange(len(candidates)), best_indexes]
                matches = best_distances <= self.recognizer.distance_threshold
                if int(np.count_nonzero(matches)) >= max(3, len(candidates) // 3):
                    names, counts = np.unique(existing_names[best_indexes[matches]], return_counts=True)
                    duplicate_name = str(names[int(np.argmax(counts))])
                    raise EnrollmentError(
                        f"This face appears to already be registered as {duplicate_name}"
                    )

            with open(os.path.join(stage, "student.json"), "w", encoding="utf-8") as handle:
                json.dump(
                    {"name": display_name, "university_id": university_id},
                    handle,
                    ensure_ascii=False,
                )
            target = os.path.join(dataset, folder_name)
            if os.path.exists(target):
                raise EnrollmentError("A student with this name already exists")
            with self.lock:
                try:
                    self.student_validator(display_name, university_id)
                except ValueError as exc:
                    raise EnrollmentError(str(exc)) from exc
                os.rename(stage, target)
                try:
                    trained = self.build_index()
                except Exception:
                    os.rename(target, stage)
                    raise
                try:
                    self.student_callback(display_name, university_id)
                except Exception:
                    shutil.rmtree(target)
                    self.build_index()
                    raise
            return {
                "name": display_name, "university_id": university_id,
                "accepted": accepted, "rejected": rejected,
                "indexed_students": trained,
            }
        finally:
            if os.path.exists(stage):
                shutil.rmtree(stage)

    def build_index(self):
        dataset = self.config["dataset_path"]
        limit = int(self.config["max_training_photos_per_student"])
        embeddings, names = [], []
        for folder_name in sorted(os.listdir(dataset)):
            folder = os.path.join(dataset, folder_name)
            if folder_name.startswith(".") or not os.path.isdir(folder):
                continue
            display_name = folder_name
            metadata = os.path.join(folder, "student.json")
            if os.path.isfile(metadata):
                with open(metadata, encoding="utf-8") as handle:
                    display_name = json.load(handle)["name"]
            filenames = sorted(
                f for f in os.listdir(folder)
                if f.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))
            )[:limit]
            usable = 0
            for filename in filenames:
                image = cv2.imread(os.path.join(folder, filename))
                embedding = self.represent(image) if image is not None else None
                if embedding is None:
                    continue
                embeddings.append(embedding)
                names.append(display_name)
                usable += 1
            if usable == 0:
                raise EnrollmentError(f"No usable DeepFace photos for {display_name}")
        if not embeddings:
            raise EnrollmentError("No DeepFace embeddings could be generated")
        output = self.config["embeddings_path"]
        directory = os.path.dirname(output)
        fd, temporary = tempfile.mkstemp(prefix=".embeddings-", suffix=".npz", dir=directory)
        os.close(fd)
        try:
            np.savez_compressed(
                temporary,
                embeddings=np.asarray(embeddings, dtype=np.float32),
                names=np.asarray(names, dtype=str),
                model_name=self.recognizer.model_name,
                detector_backend=self.recognizer.detector_backend,
            )
            os.replace(temporary, output)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
        self.recognizer.reload()
        return len(set(names))
